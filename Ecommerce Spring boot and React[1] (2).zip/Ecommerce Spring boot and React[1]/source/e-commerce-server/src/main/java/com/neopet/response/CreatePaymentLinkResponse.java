package com.neopet.response;

public class CreatePaymentLinkResponse {
	
	

}
