package com.neopet.user.domain;

public enum ProductSize {

	I, III, VI
}
