package com.neopet.user.domain;

public enum ProductCategory {

	CATS, DOGS
}
