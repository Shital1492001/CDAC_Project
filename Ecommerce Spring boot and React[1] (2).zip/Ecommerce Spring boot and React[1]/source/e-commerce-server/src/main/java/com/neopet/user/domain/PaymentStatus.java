package com.neopet.user.domain;

public enum PaymentStatus {

	PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
