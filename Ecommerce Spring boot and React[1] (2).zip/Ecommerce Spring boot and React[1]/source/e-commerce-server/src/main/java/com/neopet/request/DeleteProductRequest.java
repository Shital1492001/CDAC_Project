package com.neopet.request;

public class DeleteProductRequest {
	
//	private Long 

}
