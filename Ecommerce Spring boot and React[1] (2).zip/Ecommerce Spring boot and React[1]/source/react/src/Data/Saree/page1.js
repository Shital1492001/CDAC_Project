export const sareePage1=[
    {
        "image": "https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHBlcnNpb24lMjBjYXR8ZW58MHx8MHx8fDA%3D",
        "Brand": "pertty",
  //      "title1": "Embroidered Bollywood Georgette Saree",
        "color": "Purple",
        "selling_price": "₹789",
        "price": "₹3,999",
        "disscount": "80% off"
    },
    {
        "image": "https://miro.medium.com/v2/resize:fit:720/format:webp/1*Wrus7GQn191pNsTgtbOe8g.jpeg",
  //      "title": "Height",
        "title2": "Woven Banarasi Tissue Saree",
        "color": "Pink",
        "selling_price": "₹996",
        "price": "₹3,500",
        "disscount": "71% off"
    },
    {
        "image": "https://images.unsplash.com/photo-1518288774672-b94e808873ff?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fHBlcnNpb24lMjBjYXR8ZW58MHx8MHx8fDA%3D",
//        "title2": "Polka Print, Embroidered, Self Design Bandhani\n                          Georgett...",
        "color": "Red",
        "selling_price": "₹374",
        "price": "₹1,798",
        "disscount": "79% off"
    },
    {
        "image": "https://images.unsplash.com/photo-1503777119540-ce54b422baff?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHBlcnNpb24lMjBjYXR8ZW58MHx8MHx8fDA%3D",
  //      "title": "Size",
        "title2": "Embroidered Bollywood Georgette Saree",
        "color": "Black",
        "selling_price": "₹329",
        "price": "₹2,299",
        "disscount": "85% off"
    },
    {
        "image": "https://images.unsplash.com/photo-1529778873920-4da4926a72c2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDV8fHxlbnwwfHx8fHw%3D",
  //      "title": "Coat",
        "color": "Yellow",
        "selling_price": "₹390",
        "price": "₹942",
        "disscount": "58% off"
    },
    {
        "image": "https://images.unsplash.com/photo-1561948955-570b270e7c36?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1yZWxhdGVkfDd8fHxlbnwwfHx8fHw%3D",
//        "title": "Life Expectancy",
        "color": "Maroon",
        "selling_price": "₹497",
        "price": "₹2,899",
        "disscount": "82% off"
    }
]