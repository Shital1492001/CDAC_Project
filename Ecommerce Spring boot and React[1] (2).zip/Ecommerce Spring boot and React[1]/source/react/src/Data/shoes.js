export const mensShoesPage1=[
    {
        "image": "https://images.unsplash.com/photo-1555573710-118d1049ed07?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Z2VybWFuJTIwc2hlcGhhcmR8ZW58MHx8MHx8fDA%3D",
        "brand": "Weight",
        "title": "40-45 kgs (Male). The given Weight is same for all dogs.",
        "color": "",
        "selling_price": "₹1,455",
        "price": "₹1,599",
        "disscount": "9% off",
        "size": ""
    },
    {
        "image": "https://media.istockphoto.com/id/1439143642/photo/vertical-shot-of-a-german-shepherd-sitting-on-grass-outdoors.jpg?s=1024x1024&w=is&k=20&c=34Ee2B86nQqxn9Mu_tbHT9qvA6NC0VuM70YARizIwBg=",
        "brand": "Height",
        "title": "65-80 cms The given Height is same for all dogs.",
        "color": "",
        "selling_price": "₹1,117",
        "price": "₹1,999",
        "disscount": "44% off",
        "size": ""
    },
    {
        "image": "https://images.unsplash.com/photo-1550165298-e574b8c3c7f6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGdlcm1hbiUyMHNoZXBoZXJkfGVufDB8fDB8fHww",
        "brand": "Colour",
        "title": "Golden and Black Colours are same for the all dogs.",
        "color": "",
        "selling_price": "₹499",
        "price": "₹998",
        "disscount": "50% off",
        "size": ""
    },
    {
        "image": "https://images.unsplash.com/photo-1619980296991-5c0d64b23950?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8OXxYZDhRNzZxRTNEZ3x8ZW58MHx8fHx8",
        "brand": "Size",
        "title": "Small to Medium Size are same for the all dogs.",
        "color": "",
        "selling_price": "₹299",
        "price": "₹1,299",
        "disscount": "76% off",
        "size": ""
    },
    {
        "image": "https://images.unsplash.com/photo-1569808051202-83331a985f55?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8NnxYZDhRNzZxRTNEZ3x8ZW58MHx8fHx8",
        "brand": "Coat",
        "title": "Straight and Wavy coat are same for the all dogs.",
        "color": "",
        "selling_price": "₹249",
        "price": "₹1,299",
        "disscount": "80% off",
        "size": ""
    },
    {
        "image": "https://images.unsplash.com/photo-1649923625793-af1cbd33c8bd?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MXxYZDhRNzZxRTNEZ3x8ZW58MHx8fHx8",
        "brand": "Life Expectancy",
        "title": "8-12 years for all dogs.",
        "color": "",
        "selling_price": "₹199",
        "price": "₹999",
        "disscount": "80% off",
        "size": ""
    }
]